//
//  LoginViewController.h
//  loginPage
//
//  Created by 吴涛 on 15/12/23.
//  Copyright © 2015年 吴涛. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController

@end
