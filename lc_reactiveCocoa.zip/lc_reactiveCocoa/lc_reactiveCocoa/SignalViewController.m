//
//  SignalViewController.m
//  自学reactivecocoa
//
//  Created by liChao on 17/3/22.
//  Copyright © 2017年 蝶尚软件. All rights reserved.
//

#import "SignalViewController.h"
#import <ReactiveCocoa/ReactiveCocoa.h>

@interface SignalViewController ()
@property (strong, nonatomic) UITextField *textField;
@end

@implementation SignalViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UITapGestureRecognizer *tap = [UITapGestureRecognizer new];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        NSLog(@"three:%@", x);
    }];
    [self.view addGestureRecognizer:tap];
    
    
//    （三）RAC的KVO
    [[self.textField rac_valuesAndChangesForKeyPath:@"text" options:NSKeyValueObservingOptionNew observer:self] subscribeNext:^(id x) {
        NSLog(@"%@", x);
    }];
    
    
//    （四）RAC的通知
    
    [[[NSNotificationCenter defaultCenter] rac_addObserverForName:UIKeyboardDidShowNotification object:nil] subscribeNext:^(id x) {
        NSLog(@"键盘弹起");
    }];
    
    //代理
    self.textField.delegate = self;
    [[self rac_signalForSelector:@selector(textFieldDidBeginEditing:) fromProtocol:@protocol(UITextFieldDelegate)] subscribeNext:^(id x) {
        NSLog(@"此处打印点击信息:%@", x);
    }];
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    NSLog(@"此刻开始编辑了");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - RAC信号处理（map、filter、combine）

- (void)test1 {
    //（1）对信号不做处理
    [[self.textField rac_textSignal] subscribeNext:^(id x) {
        NSLog(@"doNothing:%@", x);
    }];
    
    //（2）对信号进行过滤（filter）
    [[[self.textField rac_textSignal] filter:^BOOL(NSString* value) {
        if (value.length > 3) {
            return YES;
        }
        return NO;
    }] subscribeNext:^(id x) {
        
        NSLog(@"filer:%@", x);
    }];
    
    //（3）对信号进行映射（map）
    [[[self.textField rac_textSignal] map:^id(NSString* value) {
        if (value.length > 3) {
            return @"map now";
        }
        return value;
    }] subscribeNext:^(id x) {
        NSLog(@"map:%@", x);
    }];
    
    //（4）信号的联合（combine）
    
    UILabel *label; UITapGestureRecognizer *tap;
    RACSignal *firstCombineSignal = [self.textField rac_textSignal];
    RACSignal *secondeCombineSignal = [tap rac_gestureSignal];
    //信号联合处理返回self.label的背景色
    RAC(label, backgroundColor) = [RACSignal combineLatest:@[firstCombineSignal, secondeCombineSignal] reduce:^id(NSString *text, UITapGestureRecognizer * tap){
        //这里进行信号逻辑判断和处理
        if (text.length == 3 && tap.state == UIGestureRecognizerStateEnded) {
            return [UIColor redColor];
        }
        return [UIColor cyanColor];
    }];
    
    //（5）信号关联
    RAC(label, text) = [self.textField rac_textSignal];
}



#pragma mark -
- (RACSignal *)signInSignal {
    return [RACSignal createSignal:^RACDisposable *(id subscriber){
//        [self.signInService
//         signInWithUsername:self.usernameTextField.text
//         password:self.passwordTextField.text
//         complete:^(BOOL success){
//             [subscriber sendNext:@(success)];
//             [subscriber sendCompleted];
//         }];
        return nil;
    }];
}
- (void)test2 {
    UIButton *btn;
    [[[btn
       rac_signalForControlEvents:UIControlEventTouchUpInside]
      map:^id(id x){
          return [self signInSignal];
      }]
     subscribeNext:^(id x){
         NSLog(@"Sign in result: %@", x);
     }];
    
}

@end
