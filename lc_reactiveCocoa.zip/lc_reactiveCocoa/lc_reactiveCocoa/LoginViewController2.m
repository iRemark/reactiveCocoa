//
//  LoginViewController2.m
//  lc_reactiveCocoa
//
//  Created by LC on 2017/3/24.
//  Copyright © 2017年 prd. All rights reserved.
//

#import "LoginViewController2.h"
#import "LQlogInRequest.h"

@interface LoginViewController2 ()

@property (strong, nonatomic) UITextField *usernameTextField;
@property (strong, nonatomic) UITextField *passwordTextField;
@property (strong, nonatomic) UIButton *loginBtn;
@property (strong, nonatomic) UIView *myView;

@end

@implementation LoginViewController2

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    CGFloat y = 70;
    self.usernameTextField = [[UITextField alloc]init];
    self.usernameTextField.frame = CGRectMake(10, y, 200, 40);
    self.usernameTextField.layer.cornerRadius = 5;
    self.usernameTextField.layer.borderWidth  = 1.0;
    [self.view addSubview:self.usernameTextField];
    
    
    y+=50;
    self.passwordTextField = [[UITextField alloc]init];
    self.passwordTextField.frame = CGRectMake(10, y, 200, 40);
    self.passwordTextField.layer.cornerRadius = 5;
    self.passwordTextField.layer.borderWidth  = 1.0;
    [self.view addSubview:self.passwordTextField];
    
    
    self.loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.loginBtn.frame = CGRectMake(300, 70, 100, 100);
    self.loginBtn.backgroundColor = [UIColor redColor];
    [self.loginBtn setTitle:@"login" forState:UIControlStateNormal];
    [self.loginBtn setTitle:@"disableLogin" forState:UIControlStateDisabled];
    [self.view addSubview:self.loginBtn];
    
    y+=50;
    self.myView = [[UIView alloc]initWithFrame:CGRectMake(10, y, 350, 100)];
    self.myView.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:self.myView];
    
    
    //判断账号是否为11位
    RACSignal *usernameSingal = [self.usernameTextField.rac_textSignal map:^id(NSString *text) {
        return @(text.length == 11);
    }];
    
    //判断密码是否为大于6位
    RACSignal *passwordSingal = [self.passwordTextField.rac_textSignal map:^id(NSString *text) {
        return @(text.length > 6);
    }];
    
    //判断当账号不为11位时，边框线为红色
    RAC(self.usernameTextField,layer.borderColor) = [usernameSingal map:^id(NSNumber *usernameValid) {
        return [usernameValid boolValue]?(id)[UIColor lightGrayColor].CGColor:(id)[UIColor redColor].CGColor;
    }];
    
    //判断当密码小于6位时，边框线为红色
    RAC(self.passwordTextField,layer.borderColor) = [passwordSingal map:^id(NSNumber *passwordValid) {
        return [passwordValid boolValue]?(id)[UIColor lightGrayColor].CGColor:(id)[UIColor redColor].CGColor;
    }];
    
    //将账号和密码的条件信号绑定到登陆按钮上,来判断按钮是否可用
    [[RACSignal combineLatest:@[usernameSingal,passwordSingal] reduce:^id(NSNumber *usernameValid , NSNumber *passwordValid){
        return @([usernameValid boolValue] && [passwordValid boolValue]);
    }]
     subscribeNext:^(NSNumber *loginBtnSingal) {
         self.loginBtn.enabled = [loginBtnSingal boolValue];
     }];
    
    [[[self.loginBtn rac_signalForControlEvents:UIControlEventTouchUpInside]
      flattenMap:^RACStream *(id value) {
          return [self loginRequest];
      }]
     subscribeNext:^(NSNumber *success) {
         if ([success boolValue])
         {
             [self performSegueWithIdentifier:@"loginSuccess" sender:self];
         }
     }];
    
}

- (RACSignal *)loginRequest
{
    LQlogInRequest *loginRequest = [LQlogInRequest new];
    
    return [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
        [loginRequest loginRequest:@"123" complete:^(BOOL success) {
            [self.view endEditing:YES];
            [subscriber sendNext:@(success)];
            [subscriber sendCompleted];
        }];
        return nil;
    }];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (void)changeMyViewBackgroundColor:(changeMyViewBackgroundColor)changeMyViewBackgroundColor
{
    changeMyViewBackgroundColor(self.myView);
}
@end
