//
//  ArrDicModelController.h
//  lc_reactiveCocoa
//
//  Created by LC on 2017/3/22.
//  Copyright © 2017年 prd. All rights reserved.
//

#import <UIKit/UIKit.h>


#import "FlagItem.h"
#import "BaseViewController.h"
@interface ArrDicModelController : BaseViewController

@end
